setwd(Sys.getenv("PWD"))
library(ggplot2)
library(plotly)
pivot_longer <- tidyr::pivot_longer
data <- read.csv(
    "changeBW.csv",
    header=TRUE,
    col.names = c(paste0(2.5*1:4), "T2DM")
)

data <- pivot_longer(data, cols=-T2DM)
data$T2DM <- ifelse(data$T2DM == 1, "T2DM", "non-T2DM")

p <- data %>%
    plot_ly(type="box") %>%
    add_trace(
        x = ~name[data$T2DM == "T2DM"],
        y = ~value[data$T2DM == "T2DM"]*100,
        color = I("tomato"),
        name = "T2DM"
    ) %>%
    add_trace(
        x = ~name[data$T2DM == "non-T2DM"],
        y = ~value[data$T2DM == "non-T2DM"]*100,
        color=I("turquoise"),
        name = "normal"
    ) %>%
    layout(
        boxmode="group",
        yaxis = list(
            title="% Change in Total BW (kg)",
            titlefont=list(size = 16),
            tickfont=list(size = 16)
        ),
        xaxis = list(
            title = "Dosing Scheme (mg/0.5mL)",
            titlefont=list(size = 16),
            tickfont=list(size = 16)
        ),
        title="% Change in Total BW over 52 Weeks for Monotonic Dosing",
        titlefont=list(size=20)
    )
print(p)
orca("percent_change_time.png")
#ggsave("percent_change_time.png", bg="white", dpi=600, height=8, width=8)
